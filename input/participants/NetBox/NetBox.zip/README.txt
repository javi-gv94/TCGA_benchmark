
Mutation_type	Point Mutations AND Copy Number Variations
CNA_file		https://s3.amazonaws.com/proddata.sagebase.org/372127/15c6cb91-d0e5-4144-b3d8-22cd0c7834d2/all_thresholded.by_genes_whitelisted.tsv?response-content-disposition=attachment%3B%20filename%3Dall_thresholded.by_genes_whitelisted.tsv&response-content-type=text%2Ftab-separated-values&AWSAccessKeyId=AKIAIV5XCDRXPWB67YRQ&Expires=1459140666&Signature=WZbfcvcXj72LCohaKXYYaoJhx70%3D
Filtering	top 50 predictions
Citation	Automated network analysis identifies core pathways in glioblastoma. PLoS One 2010

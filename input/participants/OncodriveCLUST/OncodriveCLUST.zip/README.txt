
Mutation_type	All Point Mutations
Filtering	FDR <= 0.05 || top 50 predictions
Citation	OncodriveCLUST: exploiting the positional clustering of somatic mutations to identify cancer genes. Bioinformatics 2013


Mutation_type	All Point Mutations
Filtering	top 50 predictions
Citation	Pan-cancer network analysis identifies combinations of rare somatic mutations across pathways and protein complexes. Nat Genet 2014

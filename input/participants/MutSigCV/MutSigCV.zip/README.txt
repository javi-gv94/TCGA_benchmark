
Mutation_type	All Point Mutations
Filtering	FDR <= 0.05 || top 50 predictions
Citation	Mutational heterogeneity in cancer and the search for new cancer-associated genes. Nature 2013

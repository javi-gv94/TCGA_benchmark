
Mutation_type	Missense and Nonsense Mutations
Filtering	FDR <= 0.2 || top 50 predictions
Citation	Systematic analysis of somatic mutations in phosphorylation signaling predicts novel cancer drivers. Mol Syst Biol 


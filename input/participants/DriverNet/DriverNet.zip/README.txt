
Mutation_type	Point Mutations AND Copy Number Variations
CNA_file		https://s3.amazonaws.com/proddata.sagebase.org/372127/15c6cb91-d0e5-4144-b3d8-22cd0c7834d2/all_thresholded.by_genes_whitelisted.tsv?response-content-disposition=attachment%3B%20filename%3Dall_thresholded.by_genes_whitelisted.tsv&response-content-type=text%2Ftab-separated-values&AWSAccessKeyId=AKIAIV5XCDRXPWB67YRQ&Expires=1459140666&Signature=WZbfcvcXj72LCohaKXYYaoJhx70%3D
Expression_file		https://s3.amazonaws.com/proddata.sagebase.org/372127/76e63392-4419-414e-bae7-1890660e80aa/unc.edu_PANCAN_IlluminaHiSeq_RNASeqV2.geneExp_whitelisted.tsv?response-content-disposition=attachment%3B%20filename%3Dunc.edu_PANCAN_IlluminaHiSeq_RNASeqV2.geneExp_whitelisted.tsv&response-content-type=text%2Ftab-separated-values&AWSAccessKeyId=AKIAIV5XCDRXPWB67YRQ&Expires=1459135535&Signature=ngNbl%2FXylUZ4P1S8MN3sAEiaKiU%3D
Filtering	FDR <= 0.05 || top 50 predictions
Citation	DriverNet: uncovering the impact of somatic driver mutations on transcriptional networks in cancer. Genome Biol 2012

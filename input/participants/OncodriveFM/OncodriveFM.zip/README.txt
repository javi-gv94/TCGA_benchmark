
Mutation_type	All Point Mutations
Filtering	FDR <= 0.05 || top 50 predictions
Citation	Functional impact bias reveals cancer drivers. Nucleic Acids Res 2012

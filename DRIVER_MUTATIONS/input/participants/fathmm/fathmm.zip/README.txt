
Mutation_type	Missense Mutations
Filtering	score <= -0.75
Citation	Predicting the functional, molecular, and phenotypic consequences of amino acid substitutions using hidden Markov models. Hum Mutat 2013

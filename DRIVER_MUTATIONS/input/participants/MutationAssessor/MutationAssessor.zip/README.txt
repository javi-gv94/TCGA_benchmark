
Mutation_type	Missense Mutations
Filtering	score >= 1.9
Citation	Predicting the functional impact of protein mutations: application to cancer genomics. Nucleic Acids Res 2011

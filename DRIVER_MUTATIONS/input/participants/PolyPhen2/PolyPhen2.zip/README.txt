
Mutation_type	Missense Mutations
Filtering	score <= 0.446
Citation	A method and server for predicting damaging missense mutations. Nat Methods 2010

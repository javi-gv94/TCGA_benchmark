
Mutation_type	Missense Mutations
Filtering	score >= 2
Citation	Improving the prediction of the functional impact of cancer mutations by baseline tolerance transformation. Genome Med 2012

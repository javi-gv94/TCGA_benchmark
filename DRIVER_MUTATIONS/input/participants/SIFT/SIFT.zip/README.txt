
Mutation_type	Missense Mutations
Filtering	score <= 0.05
Citation	SIFT: predicting amino acid changes that affect protein function. Nucleic Acids Res 2003
